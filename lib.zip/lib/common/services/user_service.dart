import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class UserService {
  final _supa = Supabase.instance.client;

  /// Devuelve 'admin' | 'coach' | 'client'.
  /// Si hay error/RLS/fila inexistente => 'client' y loguea el error.
  Future<String> getRole() async {
    try {
      final uid = _supa.auth.currentUser?.id;
      final email = _supa.auth.currentUser?.email;
      if (uid == null) {
        debugPrint('[UserService.getRole] uid=null -> client');
        return 'client';
      }
      final row = await _supa
          .from('app_user')
          .select('role, auth_user_id, email')
          .eq('auth_user_id', uid)
          .maybeSingle();

      final role = (row?['role'] as String?) ?? 'client';
      debugPrint(
        '[UserService.getRole] uid=$uid email=$email role=$role row=$row',
      );
      return role;
    } catch (e) {
      debugPrint('[UserService.getRole] ERROR: $e -> fallback=client');
      return 'client';
    }
  }

  /// ¿El cliente está asociado a un entrenador?
  Future<bool> isClientLinkedToTrainer() async {
    try {
      final uid = _supa.auth.currentUser?.id;
      final email = _supa.auth.currentUser?.email;
      if (uid == null) return false;

      final appUser = await _supa
          .from('app_user')
          .select('id')
          .eq('auth_user_id', uid)
          .maybeSingle();
      final appUserId = appUser?['id'];

      if (appUserId != null) {
        final bySelf = await _supa
            .from('clients')
            .select('id, trainer_id')
            .eq('app_user_id', appUserId)
            .maybeSingle();
        final linked = bySelf != null && bySelf['trainer_id'] != null;
        debugPrint('[isClientLinkedToTrainer] bySelf=$bySelf -> $linked');
        return linked;
      }

      if (email != null) {
        final byEmail = await _supa
            .from('clients')
            .select('id, trainer_id')
            .eq('email', email)
            .maybeSingle();
        final linked = byEmail != null && byEmail['trainer_id'] != null;
        debugPrint('[isClientLinkedToTrainer] byEmail=$byEmail -> $linked');
        return linked;
      }

      return false;
    } catch (e) {
      debugPrint('[isClientLinkedToTrainer] ERROR: $e -> false');
      return false;
    }
  }
}
